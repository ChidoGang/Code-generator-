function TimeElapse() {
    $("#currentDay").text(moment().format("dddd, Do of MMMM YYYY"));
}

$(document).ready(function() {
    TimeElapse()
})
